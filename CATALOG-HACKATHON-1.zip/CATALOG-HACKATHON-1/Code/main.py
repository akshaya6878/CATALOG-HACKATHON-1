import datetime

class ElectronicItem:
    def __init__(self, name, purchase_date, lifespan_years):
        self.name = name
        self.purchase_date = datetime.datetime.strptime(purchase_date, '%Y-%m-%d')
        self.lifespan_years = lifespan_years
        self.status = 'In Use'
        self.years_left = lifespan_years

    def check_lifespan(self, e_waste_items):
        current_date = datetime.datetime.now()
        end_of_life_date = self.purchase_date + datetime.timedelta(days=self.lifespan_years * 365)
        years_left = (end_of_life_date - current_date).days / 365.0
        self.years_left = round(years_left, 2)
        
        if current_date >= end_of_life_date:
            self.status = 'E-Waste'
            if self not in e_waste_items:
                e_waste_items.append(self)
        return self.years_left

def add_item(items, e_waste_items):
    name = input("Enter the name of the electronic item: ")

    # Validate purchase date input
    while True:
        try:
            purchase_date = input("Enter the purchase date (YYYY-MM-DD): ")
            purchase_date_obj = datetime.datetime.strptime(purchase_date, '%Y-%m-%d')
            if purchase_date_obj > datetime.datetime.now():
                print("Purchase date cannot be in the future. Please enter a valid date.")
            else:
                break
        except ValueError:
            print("Invalid date format. Please enter the date in YYYY-MM-DD format.")
    
    # Validate lifespan input
    while True:
        try:
            lifespan_years = int(input("Enter the lifespan of the item in years: "))
            if lifespan_years > 0:
                break
            else:
                print("Lifespan must be a positive integer.")
        except ValueError:
            print("Please enter a valid number for lifespan.")

    item = ElectronicItem(name, purchase_date, lifespan_years)
    items.append(item)
    item.check_lifespan(e_waste_items)  # Check lifespan immediately upon adding
    print(f"Item '{name}' added successfully!\n")

def update_item_status(items, e_waste_items):
    name = input("Enter the name of the item to update: ")
    for item in items:
        if item.name == name:
            if item.status == 'E-Waste':
                item.status = 'Recycled'
                print(f"Item '{name}' marked as Recycled.\n")
                e_waste_items.remove(item)
                return
            else:
                print(f"Item '{name}' is not yet E-Waste. No action taken.\n")
                return
    print(f"No item found with the name '{name}'.\n")

def delete_item(items, e_waste_items):
    name = input("Enter the name of the item to delete: ")
    for item in items:
        if item.name == name:
            items.remove(item)
            if item in e_waste_items:
                e_waste_items.remove(item)
            print(f"Item '{name}' deleted successfully!\n")
            return
    print(f"No item found with the name '{name}'.\n")

def search_item(items, e_waste_items):
    name = input("Enter the name of the item to search for: ")
    for item in items:
        if item.name == name:
            years_left = item.check_lifespan(e_waste_items)
            print(f"\nItem: {item.name}, Status: {item.status}, Years Left: {years_left}")
            return
    print(f"No item found with the name '{name}'.\n")

def display_summary(items, e_waste_items):
    total_items = len(items)
    e_waste_count = len(e_waste_items)
    
    print("\nSummary Report")
    print("-" * 30)
    print(f"Total Items: {total_items}")
    print(f"E-Waste Items: {e_waste_count}\n")

    for item in items:
        years_left = item.check_lifespan(e_waste_items)
        print(f"Item: {item.name}, Status: {item.status}, Years Left: {years_left}")
    
    if total_items > 0:
        earliest_item = min(items, key=lambda x: x.check_lifespan(e_waste_items))
        years_left = earliest_item.check_lifespan(e_waste_items)
        print(f"\nItem closest to end-of-life: {earliest_item.name} ({years_left} years left)\n")
    else:
        print("No items in the system.\n")

def list_e_waste(e_waste_items):
    print("\nE-Waste Items to be Recycled")
    print("-" * 30)

    if e_waste_items:
        for item in e_waste_items:
            print(f"Item: {item.name}, Status: {item.status}")
        print()
    else:
        print("No items are currently marked as E-Waste.\n")

def main():
    items = []
    e_waste_items = []
    print("E-Waste Monitoring System")
    print("-" * 30)
    
    while True:
        print("1. Add an Item")
        print("2. Update Item Status")
        print("3. Delete an Item")
        print("4. Search for an Item")
        print("5. Display Summary Report")
        print("6. List E-Waste Items to be Recycled")
        print("7. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            add_item(items, e_waste_items)
        elif choice == '2':
            update_item_status(items, e_waste_items)
        elif choice == '3':
            delete_item(items, e_waste_items)
        elif choice == '4':
            search_item(items, e_waste_items)
        elif choice == '5':
            display_summary(items, e_waste_items)
        elif choice == '6':
            list_e_waste(e_waste_items)
        elif choice == '7':
            print("Exiting the system. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.\n")

if __name__ == "__main__":
    main()